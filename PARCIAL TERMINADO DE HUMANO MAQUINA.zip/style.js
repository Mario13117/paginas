

const style = document.createElement('style');
style.innerHTML = `
body { font-family: Arial, sans-serif; background-color: #e6f0ff; }
#app { padding-bottom: 500px; } /* espacio para carrito y reseñas */
.card { transition: transform 0.2s; }
.card:hover { transform: scale(1.05); }
.carousel-caption h5 { color: #ffd700; }
.carousel-caption p { color: #fff; }
.btn-primary { background-color: #0047ab; border: none; }
.btn-primary:hover { background-color: #002f6c; }


.cart {
    position: fixed; bottom:0; left:0; width:100%;
    background-color:#f8f9fa; border-top:1px solid #dee2e6;
    box-shadow:0 -2px 5px rgba(0,0,0,0.1);
    max-height:40vh; overflow-y:auto; z-index:1050;
    padding:10px 20px;
}


#reviewsCarousel .carousel-item { min-height:150px; }
#reviewsCarousel img { width:80px; height:80px; object-fit:cover; }

/* Estilos para la parte de abajo de la página */
.footer {
    background: linear-gradient(180deg, #0d2355 0%, #071430 100%);
    color: #f5f7fb;
    padding: 40px 20px;
}
.footer-content {
    display: flex;
    flex-wrap: wrap;
    gap: 30px;
    justify-content: space-between;
    align-items: flex-start;
}
.footer-content.container {
    max-width: 1200px;
    margin: 0 auto;
}
.footer .linksi img {
    max-width: 160px;
    filter: drop-shadow(0 0 6px rgba(255,255,255,0.25));
}
.footer .links,
.footer .links2 {
    min-width: 180px;
}
.footer h3 {
    color: #ffffff;
    margin-bottom: 14px;
    font-size: 1.05rem;
}
.footer ul {
    list-style: none;
    padding: 0;
    margin: 0;
}
.footer li {
    margin-bottom: 10px;
}
.footer a {
    color: #cbd5e1;
    text-decoration: none;
}
.footer a:hover {
    color: #ffffff;
    text-decoration: underline;
}
.footer .app-footer {
    display: flex;
    flex-wrap: wrap;
    justify-content: space-between;
    align-items: center;
    gap: 20px;
    margin-top: 30px;
    border-top: 1px solid rgba(255,255,255,0.12);
    padding-top: 20px;
}
.footer .app-box h4 {
    color: #f8fafc;
    margin-bottom: 8px;
}
.footer .copy {
    color: #94a3b8;
    margin: 0;
}
.footer .legal-img {
    min-width: 120px;
}
.footer .small {
    color: #94a3b8;
    margin-top: 20px;
}
.footer .links2 h3 {
    font-size: 0.95rem;
    color: #cbd5e1;
    margin: 0 0 10px;
}
.footer .links2 {
    flex: 1 1 180px;
}
`;
document.head.appendChild(style);
